import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Spider {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document doc =null;
		doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen Beibei").get();
		String regex1 = "[a-z]{6}\\@[a-z]{3}\\.[a-z]{3}\\.[a-z]{2}";
		Elements intro = null;
		Elements name = null;
		//Elements to = null;
		Elements email=null; 
		Elements num=null;
		name = doc.select(".logo.col-md-4.col-sm-4");
		intro = doc.select(".details.col-md-12.col-sm-12.col-xs-12");
		email = doc.select(".details.col-md-10.col-sm-9.col-xs-7");
		num = doc.select(".details.col-md-10.col-sm-9.col-xs-7");
		String nametxt = null;
		String introtxt = null;
		//String totxt = null;
		String emailtxt = null;
		String numtxt = null;
		introtxt = intro.text();
		emailtxt = email.text();
		numtxt = num.text();
		nametxt = name.text();
		String regex2 = "[0-9]{3}\\-[0-9]{8}";
		Pattern p1 =Pattern.compile(regex2);
		Matcher m1 = p1.matcher(numtxt);
		Pattern p2 =Pattern.compile(regex1);
		Matcher m2 = p2.matcher(emailtxt);
		//totxt = to.text();
		try{
			FileWriter writer = new FileWriter("C:\\Users\\apple\\Desktop\\major\\java\\teacher.txt");
			writer.write("������");
			writer.write("\n");
			writer.write(nametxt);
			//writer.write("�о�����");
			writer.write("\n");
			//writer.write(totxt);
			writer.write("��飺");
			writer.write("\n");
			writer.write(introtxt);
			writer.write("�绰���룺");
			writer.write("\n");
			while(m1.find()){
			writer.write(m1.group());}
			writer.write("�������䣺");
			writer.write("\n");
			while(m2.find()){
			writer.write(m2.group());}
			//writer.flush();
			writer.close();
			System.out.print("sb");
		}
		catch(IOException e){
			e.printStackTrace();
		}
		catch(NullPointerException e1){
			
		}

	}

}
