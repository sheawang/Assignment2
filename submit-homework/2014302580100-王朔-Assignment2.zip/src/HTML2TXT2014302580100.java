import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class HTML2TXT2014302580100 {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
		HttpRequest2014302580100 html = HttpRequest2014302580100.get("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping");
		html.receive(new File("./teacher.html"));
		File HTML = new File("./teacher.html");
		Document doc = Jsoup.parse(HTML, "UTF-8");
		Elements a0 = doc.select("h3:matches([^a]{3})");
		String a1 = a0.text();
		Elements b0 = doc.select("p:matches(\\d{11})");
		String b1 = b0.text();
		FileWriter fw = new FileWriter("./teacher.txt");
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(a1);
		bw.write(b1);
		bw.close();
	}

}
